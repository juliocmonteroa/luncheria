<script type="text/javascript">
	success: function url(peticiones){
	//Principal inicio
	if(peticiones=='inicio'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php'")?>
	}
	//ventas
	if(peticiones=='g-venta'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=g-venta'")?>
	}
	if(peticiones=='g-devolucion'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=g-devolucion'")?>
	}
	if(peticiones=='v-dia'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=v-dia'")?>
	}
	if(peticiones=='facturas'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=facturas'")?>
	}
	if(peticiones=='facturas-a'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=facturas-a'")?>
	}
	if(peticiones=='l-precio'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=l-precio'")?>
	}
	if(peticiones=='presentacion'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=presentacion'")?>
	}
	if(peticiones=='c-producto'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=c-producto'")?>
	}
	if(peticiones=='a-producto'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=a-producto'")?>
	}
	//Sub.- Inventario
	if(peticiones=='embalaje'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=embalaje'")?>
	}
	if(peticiones=='c-insumo'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=c-insumo'")?>
	}
	if(peticiones=='a-insumo'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=a-insumo'")?>
	}
	if(peticiones=='p-entrada'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=p-entrada'")?>
	}
	if(peticiones=='p-salida'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=p-salida'")?>
	}
	//Sub.- Avanzado
	if(peticiones=='precio'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=precio'")?>
	}
	if(peticiones=='c-usuario'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=c-usuario'")?>
	}
	if(peticiones=='a-usuario'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=a-usuario'")?>
	}
	if(peticiones=='reporte'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=reporte'")?>
	}
	if(peticiones=='seguridad'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=seguridad'")?>
	}
	//Principal cerrar sesión
	if(peticiones=='salir'){
 		<?php echo ("location.href='".($GLOBALS['url'])."app/index.php?ruta=salir'")?>
	}
}
</script>