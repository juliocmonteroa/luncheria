<div class="limiter">
  <div class="container-login10">
    <div class="wrap-login10">
      <h2 align="center">
        <?php echo($GLOBALS['title']);?>
        <br><a>Bienvenido <?php echo($row_usuario["nombre"]);?> </a>
        <br><br>
        <img src="../images/inventario.png" width="200px">
        <br>
      	<?php echo($GLOBALS['copyright']);?>
      </h2>

    </div>
  </div>
</div>