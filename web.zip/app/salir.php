<?php
salir();
?>
<script type="text/javascript">
	window.location.href="../index.html"
</script>